﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bulletCollision : MonoBehaviour 
{
    void OnCollisionEnter(Collision collision)
    {
        if (collision.transform.tag == "enemyRunner" || collision.transform.tag=="enemyGunner")
        {
            Debug.Log("HIT!" + collision.transform.tag);
            Destroy(collision.gameObject);
            Destroy(gameObject);
        }
    }
}
