﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyDead : MonoBehaviour
{
    //public Vector3 hitpoint;
    
    void OnCollisionEnter(Collision other)
    {
        if(other.gameObject.tag == "weapon")
        {
            //hitpoint = collision.contacts[0].point;

            Debug.Log("Enemy Hit");
            GetComponent<Animator>().enabled = false;
            //Destroy(gameObject);
            gameObject.SetActive(false);

            //Rigidbody rb = GetComponent<Rigidbody>();
            //if (rb)
            //{
            //    rb.AddExplosionForce(1000, hitpoint, 0.5f);
            //}
        }
    }

    //void OnTriggerEnter(Collider other)
    //{
    //   if(other.gameObject.tag == "weapon")
    //    {
    //        Debug.Log("Hit Test Object");
    //    } 
    //}

    //void OnTriggerEnter(Collider other)
    //  {

    //      Debug.Log("Enemy Hit");
    //      GetComponent<Animator>().enabled = false;

    //      Rigidbody rb = GetComponent<Rigidbody>();
    //      if (rb)
    //      {
    //          rb.AddExplosionForce(1000, hitpoint, 0.5f);
    //      }
    //  }
}
