﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyShoot : MonoBehaviour
{
    public float shootRadius = 10f;
    Transform playerTarget;
    public Rigidbody bulletPrefab;
    public Transform gunEnd;
    public int fireRate;
    public Animator enemyAnim;

    void Start()
    {
        playerTarget = playerManager.instance.player.transform;
        enemyAnim = this.gameObject.GetComponent<Animator>();
        fireRate = 0;
    }

    void Update()
    {
        float distance = Vector3.Distance(playerTarget.position, transform.position);

        if (distance <= shootRadius && fireRate >= 60)
        {
            shootPlayer();
            enemyAnim.SetInteger("shoot", 1);
        }

        if(distance <= shootRadius)
        {
            FacePlayer();
        }

        fireRate++;
    }

    void shootPlayer()
    {
        fireRate = 0;
        Rigidbody bulletInstance;
        bulletInstance = Instantiate(bulletPrefab, gunEnd.position, gunEnd.rotation) as Rigidbody;
        bulletInstance.AddForce(gunEnd.forward * 1000);
    }

    void FacePlayer()
    {
        Vector3 direction = (playerTarget.position - transform.position).normalized;
        Quaternion lookRotation = Quaternion.LookRotation(new Vector3(direction.x, 0, direction.z));
        transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * 5f);
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, shootRadius);
    }
}
