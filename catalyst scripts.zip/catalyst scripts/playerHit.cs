﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class playerHit : MonoBehaviour
{
    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "enemyRunner" || collision.gameObject.name =="enemyBullet")
        {
            Debug.Log("HIT!" + collision.transform.tag);
            //Play Player Death Animation
            //Bring Up Menu to Restart or Main Menu
            SceneManager.LoadScene("main_Menu", LoadSceneMode.Single);
        }

        if (collision.gameObject.tag == "levelEnd")
        {
            SceneManager.LoadScene("main_Menu", LoadSceneMode.Single);
        }
    }
}
