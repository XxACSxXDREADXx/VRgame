﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnStart : MonoBehaviour
{
    public GameObject Player;
    public GameObject Floor1;
    public GameObject Floor2;
    public GameObject Floor3;
    GameObject[] positionData;
  
    public AudioSource songData;
    //List<GameObject> toDestroy = new List<GameObject>();

    // Start is called before the first frame update
    void Start()
    {
        //GameObject currentFloor = Instantiate(Floor1);
        positionData = GameObject.FindGameObjectsWithTag("Floor");
     
        songData = GetComponent<AudioSource>();
        songData.Play(0);
    }

    // Update is called once per frame
    void Update()
    {
      
        for(int i = 0; i < positionData.Length; i++)
        {
            if(positionData[i].transform.position.z < Player.transform.position.z && Vector3.Distance(Player.transform.position, positionData[i].transform.position) > 40)
            {
                positionData[i].transform.position = new Vector3(positionData[i].transform.position.x, positionData[i].transform.position.y, positionData[i].transform.position.z + (positionData.Length * 80));

            }
        }      
    }
}
