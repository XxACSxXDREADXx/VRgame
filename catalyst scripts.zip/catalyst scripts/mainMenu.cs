﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class mainMenu : MonoBehaviour
{
    public void menuStart()
    {
        Debug.Log("Start Hit");
        SceneManager.LoadScene("test_level_1", LoadSceneMode.Single);
    }

    public void menuExit()
    {
        Debug.Log("Exit Hit");
        Application.Quit();
    }
}
