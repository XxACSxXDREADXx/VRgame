﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyLook : MonoBehaviour
{
    public int playerFound;
    public Transform Player;
    public float enemySpeed = 4f;
    public Animator enemyStart;
    public GameObject[] Enemies;
    
    
    
    void Start()
    {
        Debug.Log("Looking For Player"); //Check at start the enemy is looking for player
        enemyStart = gameObject.GetComponent<Animator>(); //getting component of animator attached to the enemy
        enemyStart.SetInteger("start", 0);
        Physics.gravity = new Vector3(0, -1F, 0);

        //Enemies = GameObject.FindGameObjectsWithTag("Enemy");

        playerFound = 1;
    }


    //void OnTriggerEnter(Collider other)
    //{
    //    Debug.Log("Found Player");//checks to see if the player collided with sphere collider
    //    playerFound = 1; //set variable to true
    //}

    void Update()
    {
        transform.forward = Vector3.ProjectOnPlane((Camera.main.transform.position - transform.position), Vector3.up).normalized; //allows for the enemy to always look towards player

        //if(Player != null)
        //{
        //    for(int i = 0; i < Enemies.Length; i++)
        //    {
        //        float dist = Vector3.Distance(Player.position, Enemies[i].transform.position);
        //        Debug.Log(dist);
        //        if (dist <= 5)
        //        {
        //            playerFound = 1;
        //        }
        //        else
        //        {
        //            playerFound = 0;
        //        }
        //    }
        //}

        if (playerFound == 1)
        {
            enemyStart.SetInteger("start", 1);//tell animator to start the transistion
            //float step = enemySpeed * Time.deltaTime; // calculate distance to move
            //transform.position = Vector3.MoveTowards(transform.position, Player.position, 3);//moves the enemy towards the player.
            transform.position += (Player.position - transform.position).normalized * enemySpeed * Time.deltaTime;
        }

    }
}
