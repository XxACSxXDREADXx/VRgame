﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gunHeld : MonoBehaviour
{
    public int isHeld = 0;
    //public Rigidbody pGun;
    //public Rigidbody pHand;

    // Start is called before the first frame update
    void Start()
    {
        //isHeld = 0;
        print("isHeld = 0");
        //Collider handHandler = pHand.gameObject.GetComponent<Collider>();
        //Collider gunHandler = pGun.gameObject.GetComponent<Collider>();
    }

    void OnCollisionEnter(Collision other)
    {
        if(other.gameObject.tag == "rHand")
        {
            isHeld = 1;
            Debug.Log("Hit");
        }
        else
        {
            isHeld = 0;
        }
        //isHeld = 1;
        //print("Collision Detected");
    }

}
