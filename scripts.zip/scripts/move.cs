﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move : OnStart
{
    public int playerHit = 0;

    void OnTriggerEnter(Collider other)
    {
        Debug.Log("Hit Player");
        playerHit = 1;
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += Time.deltaTime * new Vector3(0, 0, 2);

        if(playerHit == 1)
        {
            songData.Stop();
        }
    }
}
