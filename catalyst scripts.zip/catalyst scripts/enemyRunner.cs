﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class enemyRunner : MonoBehaviour
{
    public float attackRadius = 2.0F;
    public Animator animator;

    Transform playerTarget;
    

    // Start is called before the first frame update
    void Start()
    {
        playerTarget = playerManager.instance.player.transform;
        animator = this.gameObject.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        float distance = Vector3.Distance(playerTarget.position, transform.position);

        if (distance <= attackRadius)
        {
            animator.SetInteger("Run", 0);
            enemyAttack();
        }
    }

    void enemyAttack()
    {
        //Set-Up animation of enemy throwing a punch
        animator.SetInteger("Attack", 1);
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, attackRadius);
    }
}
