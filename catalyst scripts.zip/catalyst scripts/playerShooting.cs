﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class playerShooting : MonoBehaviour 

{

    public Rigidbody bulletPrefab;
    public Transform gunEnd;
    public int maxAmmo = 10;
    public int currentAmmo = 10;
    public TextMeshPro ammoCounter;
 
    void Start()
    {
        ammoCounter.text = currentAmmo.ToString();
    }

    // Update is called once per frame
    void Update () {

        //if(OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, OVRInput.Controller.RTouch) && this.gameObject.transform.parent.gameObject.name == "RightHandAnchor")
        //{
        //    GameObject instBullet = Instantiate(bulletPrefab, gunEnd.position, gunEnd.rotation) as GameObject;
        //    Rigidbody instBulletRigidbody = instBullet.GetComponent<Rigidbody>();
        //    instBulletRigidbody.AddForce(Vector3.forward * 1000);
        //    //anin.Play("Outer_Case");
        //}



        if (OVRInput.GetDown(OVRInput.Button.SecondaryIndexTrigger))
        {
            Debug.Log("Trigger Pressed");

            if (currentAmmo > 0)
            {
                Shoot();
            }
            else
            {
                Debug.Log("No Ammo");
            }
        }
        if(Vector3.Angle(transform.up, Vector3.up) > 100 && currentAmmo < maxAmmo)
        {
            Reload();
        }

        ammoCounter.text = currentAmmo.ToString();

    }

    void Reload()
    {
        currentAmmo = maxAmmo;
    }

    void Shoot()
    {
        currentAmmo--;

        Rigidbody bulletInstance;
        bulletInstance = Instantiate(bulletPrefab, gunEnd.position, gunEnd.rotation) as Rigidbody;
        bulletInstance.AddForce(gunEnd.forward * 1000);
    }
}
