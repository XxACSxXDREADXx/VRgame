﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyBulletCollision : MonoBehaviour
{
    void OnCollisionEnter(Collision collision)
    {
        if (collision.transform.tag == "Player")
        {
            Debug.Log("HIT!" + collision.transform.tag);
            //Destroy(collision.gameObject);
            Destroy(gameObject);
        }
    }
}
