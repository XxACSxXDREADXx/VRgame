﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class enemyController : MonoBehaviour
{
    public Animator enemyAnim;
    public float lookRadius = 10f;
    public float attackRadius = 2.0F;

    Transform playerTarget;
    NavMeshAgent runnerAgent;

    // Start is called before the first frame update
    void Start()
    {
        playerTarget = playerManager.instance.player.transform;
        runnerAgent = GetComponent<NavMeshAgent>();
        enemyAnim = this.gameObject.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        float distance = Vector3.Distance(playerTarget.position, transform.position);

        if(distance <= lookRadius)
        {
            runnerAgent.SetDestination(playerTarget.position);
            
            if(enemyAnim.GetInteger("Attack") == 0)
            {
                enemyAnim.SetInteger("Run", 1);
            }
            else
            {
                enemyAnim.SetInteger("Run", 0);
            }

            if (distance<= runnerAgent.stoppingDistance)
            {
                //Attack the player
                enemyAttack();
                //Face the player
                FacePlayer();
            }
        }
    }

    void FacePlayer()
    {
        Vector3 direction = (playerTarget.position - transform.position).normalized;
        Quaternion lookRotation = Quaternion.LookRotation(new Vector3(direction.x, 0, direction.z));
        transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * 5f);
    }

    void enemyAttack()
    {
        //Set-Up animation of enemy throwing a punch
        enemyAnim.SetInteger("Attack", 1);
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, lookRadius);
        Gizmos.DrawWireSphere(transform.position, attackRadius);
    }
}
